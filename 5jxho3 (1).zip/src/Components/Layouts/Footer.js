import React from 'react'
import { AppBar, Tabs, Tab } from '@mui/material'
import { useTheme } from '@mui/material/styles'
import useMediaQuery from '@mui/material/useMediaQuery'
export default ({ muscles, category, onSelect }) => {
  let index = category
    ? muscles.findIndex((group) => group === category) + 1
    : 0
  const onIndexSelect = (e, id) => {
    onSelect(id === 0 ? '' : muscles[id - 1])
  }
  function useWidth() {
    const theme = useTheme()
    const keys = [...theme.breakpoints.keys].reverse()
    return (
      keys.reduce((output, key) => {
        // eslint-disable-next-line react-hooks/rules-of-hooks
        const matches = useMediaQuery(theme.breakpoints.up(key))
        return !output && matches ? key : output
      }, null) || 'xs'
    )
  }
  const width = useWidth()
  return (
    <AppBar position="static" backgroundcolor="primary">
      <Tabs
        onChange={onIndexSelect}
        value={index}
        textColor="primary"
        indicatorColor="secondary"
        centered={width !== 'xs'}
        scrollable={width === 'xs'}
        // variant="standard"
      >
        <Tab label="All" />
        {muscles.map((group, id) => (
          <Tab label={group} key={id} />
        ))}
      </Tabs>
    </AppBar>
  )
}

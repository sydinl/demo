import React from 'react'
import { AppBar, Toolbar, Typography } from '@mui/material'
import CreateDialog from '../Exercises/Dialog'
export default ({ muscles, onExerciseCreate }) => (
  <AppBar position="static" backgroundcolor="primary">
    <Toolbar>
      <Typography variant="h6" color="inherit" sx={{ flex: 1 }}>
        Exercise Database
      </Typography>
      <CreateDialog muscles={muscles} onCreate={onExerciseCreate} />
    </Toolbar>
  </AppBar>
)

import React, { useState } from 'react'
import Exercises from './Exercises'
import { Header, Footer } from './Layouts'
import { muscles, exercises as excises } from '../store'
import { ThemeProvider } from '@mui/material/styles'
import theme from '../theme'
export default () => {
  const [exercises, setExercises] = useState([...excises])
  const [category, setCategory] = useState('legs')
  const [exercise, setExercise] = useState({})
  const [editMode, setEditMode] = useState(false)
  const getExercisesByMuscles = () => {
    const initExercises = muscles.reduce(
      (exercises, muscle) => ({
        ...exercises,
        [muscle]: []
      }),
      {}
    )
    return Object.entries(
      exercises.reduce((exercises, exercise) => {
        const { muscles } = exercise
        exercises[muscles] = [...exercises[muscles], exercise]
        return exercises
      }, initExercises)
    )
  }
  const handleCategorySelect = (category) => {
    setCategory(category)
  }
  const handleExerciseSelect = (id) => {
    setExercise(exercises.find((ex) => ex.id === id))
    setEditMode(false)
  }
  const handleExerciseCreate = (exercise) => {
    setExercises([...exercises, exercise])
  }
  const handleExerciseDelete = (id) => {
    setExercises(exercises.filter((exercise) => exercise.id !== id))
    if (exercise.id === id) {
      setEditMode(false)
      setExercise({})
    }
  }
  const handleExerciseSelectEdit = (id) => {
    setExercise(exercises.find((ex) => ex.id === id))
    setEditMode(true)
  }
  const handleExerciseEdit = (exercise) => {
    setExercises([...exercises.filter((ex) => ex.id !== exercise.id), exercise])
    setExercise(exercise)
  }
  console.log(theme)
  return (
    <ThemeProvider theme={theme}>
      <Header muscles={muscles} onExerciseCreate={handleExerciseCreate} />
      <Exercises
        exercises={getExercisesByMuscles()}
        category={category}
        exercise={exercise}
        onSelect={handleExerciseSelect}
        onDelete={handleExerciseDelete}
        onSelectEdit={handleExerciseSelectEdit}
        editMode={editMode}
        muscles={muscles}
        onEdit={handleExerciseEdit}
      />
      <Footer
        muscles={muscles}
        category={category}
        onSelect={handleCategorySelect}
      />
    </ThemeProvider>
  )
}

import React, { Fragment } from 'react'
import {
  Typography,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  IconButton
} from '@material-ui/core'
import { Edit, Delete } from '@material-ui/icons'
import { makeStyles, createStyles } from '@mui/styles'

const useStyles = makeStyles((theme) =>
  createStyles({
    title: {
      textTransform: 'capitalize'
    }
  })
)

const Catalog = ({ exercises, category, onSelect, onDelete, onSelectEdit }) => {
  const classes = useStyles()
  return exercises.map(
    ([group, exercises]) =>
      (!category || category === group) && (
        <Fragment key={group}>
          <Typography className={classes.title} color="secondary" variant="h5">
            {group}
          </Typography>
          <List component="ul">
            {exercises.map(({ id, title }) => (
              <ListItem key={id} button onClick={() => onSelect(id)}>
                <ListItemText primary={title} />
                <ListItemSecondaryAction>
                  <IconButton color="primary" onClick={() => onSelectEdit(id)}>
                    <Edit />
                  </IconButton>
                  <IconButton color="primary" onClick={() => onDelete(id)}>
                    <Delete />
                  </IconButton>
                </ListItemSecondaryAction>
              </ListItem>
            ))}
          </List>
        </Fragment>
      )
  )
}

export default Catalog

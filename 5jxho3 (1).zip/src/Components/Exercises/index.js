import React from 'react'
import { Fragment } from 'react'
import {
  Grid,
  Paper,
  Typography,
  List,
  ListItem,
  ListItemText,
  IconButton,
  ListItemButton
} from '@mui/material'
import { makeStyles, createStyles } from '@mui/styles'
import DeleteIcon from '@mui/icons-material/Delete'
import EditIcon from '@mui/icons-material/Edit'
import Form from './Form'
const TITLE = 'Welcome'
const DESC = 'Please select an exercise from the list on the left.'
const useStyles = makeStyles((theme) =>
  createStyles({
    paper: {
      padding: 20,
      [theme.breakpoints.up('sm')]: {
        marginTop: 10,
        height: 'calc(100% - 10px)'
      },
      [theme.breakpoints.down('sm')]: {
        height: '100%'
      },
      overflowY: 'auto'
    },
    '@global': {
      'html,body,#root': {
        height: '100%'
      }
    },
    container: {
      [theme.breakpoints.up('sm')]: {
        height: 'calc(100% - 64px - 48px)'
      },
      [theme.breakpoints.down('sm')]: {
        height: 'calc(100% - 56px - 48px)'
      }
    },
    item: {
      [theme.breakpoints.down('sm')]: {
        height: '50%'
      }
    }
  })
)
const Exercises = ({
  exercises,
  category,
  onSelect,
  exercise,
  onDelete,
  onSelectEdit,
  editMode,
  muscles,
  onEdit
}) => {
  const classes = useStyles()
  return (
    <Grid container className={classes.container}>
      <Grid item className={classes.item} xs={12} sm={6}>
        <Paper className={classes.paper}>
          {exercises.map(([group, exercises]) =>
            !category || category === group ? (
              <Fragment key={group}>
                <Typography variant="h6" sx={{ textTransform: 'capitalize' }}>
                  {group}
                </Typography>
                <List component="ul">
                  {exercises.map(({ id, title }) => (
                    <ListItem
                      key={id}
                      secondaryAction={
                        <>
                          <IconButton
                            edge="end"
                            aria-label="edit"
                            onClick={() => onSelectEdit(id)}
                            color="primary"
                          >
                            <EditIcon />
                          </IconButton>
                          <IconButton
                            edge="end"
                            aria-label="delete"
                            onClick={() => onDelete(id)}
                            color="primary"
                          >
                            <DeleteIcon />
                          </IconButton>
                        </>
                      }
                    >
                      <ListItemButton onClick={() => onSelect(id)}>
                        <ListItemText primary={title} />
                      </ListItemButton>
                    </ListItem>
                  ))}
                </List>
              </Fragment>
            ) : null
          )}
        </Paper>
      </Grid>
      <Grid item className={classes.item} xs={12} sm={6}>
        <Paper className={classes.paper}>
          <Typography variant="h2" gutterBottom>
            {exercise.title ? exercise.title : TITLE}
          </Typography>
          {editMode ? (
            <Form muscles={muscles} onSubmit={onEdit} ex={exercise} />
          ) : (
            <Typography variant="subtitle1" sx={{ marginTop: '20' }}>
              {exercise.title ? exercise.description : DESC}
            </Typography>
          )}
        </Paper>
      </Grid>
    </Grid>
  )
}
export default Exercises

import React, { useState } from 'react'
import {
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Button
} from '@mui/material'

const initExercise = {
  title: '',
  description: '',
  muscles: ''
}
export default ({ muscles, ex, onSubmit }) => {
  const [exercise, setExercise] = useState(ex ? { ...ex } : { ...initExercise })
  const handleChange = (name) => ({ target: { value } }) => {
    setExercise({ ...exercise, [name]: value })
  }
  const handleSubmit = () => {
    onSubmit({
      id: exercise.title.toLowerCase().replace(/ /g, '-'),
      ...exercise
    })
  }
  return (
    <form>
      <TextField
        label="Title"
        variant="standard"
        value={exercise.title}
        onChange={handleChange('title')}
        fullWidth
      />
      <br />
      <FormControl variant="standard" fullWidth>
        <InputLabel>Muscles</InputLabel>
        <Select
          labelId="demo-simple-select-standard-label"
          id="demo-simple-select-standard"
          value={exercise.muscles}
          onChange={handleChange('muscles')}
          label="Muscles"
        >
          {muscles.map((muscle, id) => (
            <MenuItem key={id} value={muscle}>
              {muscle}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
      <br />
      <TextField
        label="Description"
        variant="standard"
        multiline
        rows={4}
        value={exercise.description}
        onChange={handleChange('description')}
        fullWidth
      />
      <br />
      <Button
        variant="contained"
        onClick={handleSubmit}
        sx={{ marginTop: 1 }}
        disabled={!exercise.title || !exercise.muscles}
      >
        {ex ? 'Edit' : 'Create'}
      </Button>
    </form>
  )
}

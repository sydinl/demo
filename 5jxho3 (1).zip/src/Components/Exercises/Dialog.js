import React, { Fragment, useState } from 'react'
import {
  Dialog,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Button
} from '@mui/material'
import AddCircleOutlineRoundedIcon from '@mui/icons-material/AddCircleOutlineRounded'
import Form from './Form'

export default ({ muscles, onCreate }) => {
  const [open, setOpen] = useState(false)
  const handleToggle = () => setOpen(!open)
  const handleSubmit = (exercise) => {
    //todo validate
    onCreate(exercise)
    setOpen(false)
  }
  // sx={{ color: 'white' }}
  return (
    <Fragment>
      <Button onClick={handleToggle} color="secondary">
        <AddCircleOutlineRoundedIcon />
      </Button>
      <Dialog open={open} onClose={handleToggle} maxWidth="xs" fullWidth>
        <DialogTitle>Create a New Exercise</DialogTitle>
        <DialogContent>
          <DialogContentText>Please fill out the form below</DialogContentText>
          <Form muscles={muscles} onSubmit={handleSubmit} />
        </DialogContent>
      </Dialog>
    </Fragment>
  )
}
